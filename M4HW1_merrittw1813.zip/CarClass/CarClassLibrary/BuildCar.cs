﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarClassLibrary
{
    public class BuildCar
    {
        public static Car BuildACar(Car thisCar) 
        {
            
            bool error = false; //Boolean test for do while.

            do
            {
                Console.WriteLine("What is the year of the car? ");
                Console.Write("--->");
                thisCar.CarYear = ConvertToInt(Console.ReadLine());

                Console.WriteLine("What is the make of the car? ");
                Console.Write("--->");
                thisCar.CarMake = Console.ReadLine();

                if (thisCar.CarYear < 0)
                {
                    error = true;
                    Console.WriteLine("Error! Invalid vehicle year!");
                }
                else 
                {
                    error = false;
                }

            } while (error == true);

            return thisCar;

        }

        public static int ConvertToInt(string input) 
        {
            int output = 0;

            if (int.TryParse(input, out output))
            {
                return output;
            }
            else 
            {
                //-1 will not be a valid year
                output = -1;
                return output;
            }
        }
    }
}
