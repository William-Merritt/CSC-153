﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
* 03/21/2020
* CSC 153
* William Merritt
* Creating a car class to demo classes, constructors, fields, and methods. 
*/
namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;


            //Creating a list to hold the user vehicles
            //List<CarClassLibrary.Car> cars = new List<CarClassLibrary.Car>();
            
            //Creating a Car Object without the need for a list or an array. 
            CarClassLibrary.Car userCar = new CarClassLibrary.Car();

            do
            {
                Console.WriteLine(CarClassLibrary.StandardMessages.DisplayMenu());
                

                switch (Console.ReadLine()) 
                {
                    case "1" :
                        //Calling the build car class to prompt user for car information
                        CarClassLibrary.BuildCar.BuildACar(userCar);
                        Console.WriteLine(CarClassLibrary.StandardMessages.DisplayCarObject(userCar));
                        break;

                    case "2" :
                        //Calling the Accelerate method car's speed goes up by 5.
                        userCar.Accelerate();
                        Console.WriteLine(CarClassLibrary.StandardMessages.CleaningCode());
                        Console.WriteLine($"Current Car speed is ---> {userCar.CarSpeed}");
                        Console.WriteLine(CarClassLibrary.StandardMessages.CleaningCode());
                        break;

                    case "3" :
                        //Do not need console write line for void methods.
                        //Calling the brake method, car's speed goes down by 5.
                        userCar.Brake();
                        Console.WriteLine(CarClassLibrary.StandardMessages.CleaningCode());
                        Console.WriteLine($"Slowing Down. Current Speed is ---> {userCar.CarSpeed}");
                        Console.WriteLine(CarClassLibrary.StandardMessages.CleaningCode());
                        break;

                    case "4" :
                        exit = true;
                        break;

                    default :
                        Console.WriteLine(CarClassLibrary.StandardMessages.DisplayNumError());
                        break;
                }
            } while (exit == false);
        }
    }
}
