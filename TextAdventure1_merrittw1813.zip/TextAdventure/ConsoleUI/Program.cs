﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
* 02/03/2020
* CSC 153
* William Merritt
* This program will be the first pass of the Text Adventure 
* Semester Project.
*/


namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool valid;
            
            
            string[] rooms;
            string[] weapons;
            string[] potions;
            string[] treasure;
            
            List<string> items;
            List<string> mobs;

            rooms = new string[5] { "Entrance", "Plaza", "Alley", "Field", "Castle" };
            weapons = new string[4] { "Sword", "Lance", "Axe", "Bow" };
            potions = new string[2] { "Health Potion", "Stamina Potion" };
            treasure = new string[3] { "Money", "Scroll", "Gemstone" };

            items = new List<string>() { "Food", "Armor", "Metals", "Ring" };
            mobs = new List<string>() { "Knight", "Soilder", "Commander", "Calvary",
                "Dogs"};
            
            do
            {
                valid = false;

                Console.WriteLine("Please select a menu option"
                    + "\n1. Display Rooms"
                    + "\n2. Display Weapons"
                    + "\n3. Display Potions"
                    + "\n4. Display Treasures"
                    + "\n5. Display Items"
                    + "\n6. Display Mobs"
                    + "\n7. Exit");
                
                //Creating the variable to hold user choice
                string userChoice = System.Console.ReadLine();

                //Running that variable through a switch statement with multiple cases.
                switch (userChoice) 
                {
                    case "1":
                        Console.WriteLine("These are the rooms of Larvan"
                            +"\n==============================");
                        foreach (string element in rooms) 
                        {
                            Console.WriteLine(element);
                        }
                        Console.WriteLine("Please press ENTER once to continue");
                        Console.ReadLine();
                        break;

                    case "rooms":
                        Console.WriteLine("These are the rooms of Larvan"
                            + "\n==============================");
                        foreach (string element in rooms)
                        {
                            Console.WriteLine(element);
                        }
                        Console.WriteLine("Please press ENTER once to continue");
                        Console.ReadLine();
                        break;

                    case "2":
                        Console.WriteLine("These are the Weapons"
                            + "\n============================");
                        
                        System.Array.Sort(weapons);
                        
                        foreach (string element in weapons) 
                        {
                            Console.WriteLine(element);
                        }
                        Console.WriteLine("Please press ENTER once to continue");
                        Console.ReadLine();
                        break;

                    case "weapons":
                        Console.WriteLine("These are the Weapons"
                            + "\n============================");
                        foreach (string element in weapons)
                        {
                            Console.WriteLine(element);
                        }
                        Console.WriteLine("Please press ENTER once to continue");
                        Console.ReadLine();
                        break;

                    case "3":
                        Console.WriteLine("These are your current Potions"
                            + "\n===========================");
                        foreach (string element in potions) 
                        {
                            Console.WriteLine(element);
                        }
                        Console.WriteLine("Please press ENTER once to continue");
                        Console.ReadLine();
                        break;

                    case "4":
                        Console.WriteLine("These are your current Treasures"
                           + "\n===========================");
                        foreach (string element in treasure)
                        {
                            Console.WriteLine(element);
                        }
                        Console.WriteLine("Please press ENTER once to continue");
                        Console.ReadLine();
                        break;

                    case "5":
                        Console.WriteLine("These are your current Items"
                           + "\n===========================");
                        foreach (string element in items)
                        {
                            Console.WriteLine(element);
                        }
                        Console.WriteLine("Please press ENTER once to continue");
                        Console.ReadLine();
                        break;
                    
                    case "6":
                        Console.WriteLine("These are the current Mobs of Larvan"
                           + "\n===========================");
                        foreach (string element in mobs)
                        {
                            Console.WriteLine(element);
                        }
                        Console.WriteLine("Please press ENTER once to continue");
                        Console.ReadLine();
                        break;

                    case "7":
                        Console.WriteLine("Have a nice day");
                        Console.WriteLine("Please press ENTER once to quit the program.");
                        Console.ReadLine();
                        valid = true;
                        break;

                    case "north" :
                        //Typing north show everything in the array 
                        //was not sure how to approach just doing one at a time
                        for (int index = 0; index < rooms.Length; index++) 
                        {
                            Console.WriteLine(rooms[index]);
                            Console.WriteLine($"You're now in the {index}. ");
                        }
                        Console.WriteLine("Please press ENTER once to continue");
                        Console.ReadLine();
                        break;

                    case "south" :
                        //Typing south shows everything in the array 
                        //was not sure how to approach just doing one at a time
                        for (int index = rooms.Length - 1; index >= 0; index--) 
                        {
                            Console.WriteLine(rooms[index]);
                            Console.WriteLine($"You're now in the {index}. ");
                        }
                        Console.WriteLine("Please press ENTER once to continue");
                        Console.ReadLine();
                        break; 

                    default :
                        Console.WriteLine("\nError: Please enter a value from the menu");
                        Console.ReadLine();
                        break;
                }


            } while (!valid);
        }
    }
}
