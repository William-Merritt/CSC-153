﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    public static class CalculatingCost
    {
        public static double CalculateRetail(double wholeSaleCost, double percentage) 
        { 
            double retailCost = wholeSaleCost + wholeSaleCost * percentage / 100;

            return retailCost;
        }

        public static double ConvertingWholeSale(ref string cost) 
        {
            if (double.TryParse(cost, out double wholeSaleCost)) 
            {
                Console.WriteLine("Number entered has been saved!");
            }
            return wholeSaleCost;
        }

        public static double ConvertingMarkup(ref string markup)
        {
            if (double.TryParse(markup, out double percentage))
            {
                Console.WriteLine("Number entered has been saved!");
            }
            return percentage;
        }


    }
}
