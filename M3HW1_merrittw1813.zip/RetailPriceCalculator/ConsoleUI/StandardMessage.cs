﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    public static class StandardMessage
    {
        public static void DisplayMainMenu()
        {
            Console.WriteLine("1. Enter Wholesale Cost.");
            Console.WriteLine("2. Enter Markup Percentage.");
            Console.WriteLine("3. Display Retail Cost.");
            Console.WriteLine("4. Exit Program.");
            Console.Write("Please Enter 1/2/3/4 -->");
        }

        public static void AskForWholesale() 
        {
            Console.Write("Enter a wholesale cost ----> ");
        }

        public static void AskForMarkup() 
        {
            Console.Write("Enter a markup percentage ----> ");
        }
        public static void DisplayNumberError() 
        {
            Console.WriteLine("You have entered an incorrect menu choice!");
        }

        public static void DisplayConfirmation()
        {
            Console.WriteLine("Number has been entered into equation");
        }

        public static void DisplayGoodbye() 
        {
            Console.WriteLine("Have a nice day");
        }

        public static void DisplayCost(ref double display) 
        {
            Console.WriteLine($"The retail cost of the product is -----> {display}");
        }

        public static void CleaningCode() 
        {
            Console.WriteLine(" ");
        }
    }
}
