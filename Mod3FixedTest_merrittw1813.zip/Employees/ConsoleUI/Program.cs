﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
 * William Merritt
 * CSC 153
 * 02/26/2020   
 * Employees Test 2 Breaking the code into Methods
 */
namespace ConsoleUI
{
    class Program
    {
        
        
        static void Main(string[] args)
        {
            //Create input variable for user input and sentry for loop
            string input;
            bool exit = false;
            int nameIndex = 0, phoneIndex = 0;

            //Create a constant variable to hold size of the arrays
            const int SIZE = 5;

            //Create Arrays passing through size array
            string[] employeeNames = new string[SIZE];
            string[] employeePhones = new string[SIZE];

            //Create a List for the employees Age. 
            List<int> employeeAges = new List<int>();

            do
            {
                //Calling the menu void method to display to the user and get back input
                Console.WriteLine(EmployeeLibrary.StandardMessages.DisplayMenu());
                input = Console.ReadLine();

                //Creating the Decision Structure (Switch) to direct proper process
                switch (input) 
                {
                    case "1" :
                        //Calling the void method GetEmployeeName
                        Console.Write(EmployeeLibrary.StandardMessages.PromptForName());
                        //Overwrite users input from menu Choice.
                        input = Console.ReadLine();
                        //Passing input and employeeNames as parameters to EnterName Method
                        EmployeeLibrary.EmployeeMethods.EnterName(ref employeeNames, ref nameIndex, input);
                        EmployeeLibrary.StandardMessages.CleaningCode();
                        break;

                    case "2" :
                        //calling the void method GetEmployeePhoneNum
                        Console.Write(EmployeeLibrary.StandardMessages.PromptForEmployeePhoneNum());
                        input = Console.ReadLine();
                        //Passing input and employeePhones as parameters.
                        EmployeeLibrary.EmployeeMethods.EnterPhone(ref employeePhones, ref phoneIndex, input);
                        break;

                    case "3" :
                        Console.Write(EmployeeLibrary.StandardMessages.PromptForEmployeeAge());
                        input = Console.ReadLine();
                        //Passing input and employeeAges as parameters
                        employeeAges = EmployeeLibrary.EmployeeMethods.EnterAge(employeeAges, input);
                        break;

                    case "4" :
                        //Passing each array and list and calling the display method. 
                        EmployeeLibrary.EmployeeMethods.DisplayEmpInfoToUser(employeeNames, employeePhones, employeeAges);
                        break;

                    case "5" :
                        //Passing employeeAges list and calling the DisplayAverageAge Method. 
                        EmployeeLibrary.StandardMessages.DisplayAverageAge(ref employeeAges);
                        EmployeeLibrary.StandardMessages.CleaningCode();
                        break;

                    case "6" :
                        //Calling the display goodbye void method
                        EmployeeLibrary.StandardMessages.DisplayGoodbye();
                        EmployeeLibrary.StandardMessages.CleaningCode();
                        exit = true;
                        break;

                    default :
                        Console.WriteLine(EmployeeLibrary.StandardMessages.DisplayNumberError());
                        break;


                }

            } while (exit == false);


        }
    }
}
