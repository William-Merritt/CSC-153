﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public static class StandardMessages
    {
        public static string DisplayMenu() 
        {
            return "1. Enter Employee's Name\n2. Enter Employee's phone number\n3. Enter Employee's Age" +
                "\n4. Display Employee Information\n5. Display Average Age of Employees\n6. Exit\n--> ";
        }

        public static string PromptForName() 
        {
            return "Enter The Employee's Name ----> ";
        }

        public static string PromptForEmployeePhoneNum() 
        {
            return "Enter The Employee's Phone Number ----> ";
        }

        public static string PromptForEmployeeAge() 
        {
            return "Enter The Employee's Age ----> ";
        }

        public static string DisplayGoodbye() 
        {
            return "Have a nice day";
        }

        public static void CleaningCode() 
        {
            Console.WriteLine(" ");
        }

        public static string DisplayNumberError()
        {
            return "Error! Not a valid number!";
        }

        public static string DisplayEmployee(string[] name, string[] phone, List<int> age, int index) 
        {
            return $"Employee Name - {name[index]}\n" +
                   $"Employee Phone - { phone[index]}\n" +
                   $"Employee Age - {age[index]}";
        } 

        public static void DisplayAverageAge(ref List<int> employeeAges) 
        {
            double showAverageAge = employeeAges.Average();
            CleaningCode();
            Console.WriteLine($"The average employee age is ---> {showAverageAge} ");
        }

    }
}
