﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PeopleClassLibrary;

namespace ConsoleUI
{
    public static class DisplayCustomerInfo
    {
        // Creating a Class to display customer information
        // This is for good practice and just incase changes need to be made in the future. 
        public static void DisplayCustomer(Customer thisCustomer) 
        {
            Console.WriteLine($"Customer Name ---> {thisCustomer.Name}\n" +
                $"Customer Address ---> {thisCustomer.Address}\n" +
                $"Custoemr Telephone Number ---> {thisCustomer.TelephoneNum}\n" +
                $"Customer Number ---> {thisCustomer.CustomerNum}\n" +
                $"Added to Mailing List ---> {thisCustomer.MailingList}");
        }
    }
}
