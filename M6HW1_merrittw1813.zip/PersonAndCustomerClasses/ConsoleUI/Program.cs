﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PeopleClassLibrary;
/**
 * William Merritt
 * CSC 153
 * 04/20/2020   
 * This program will demo inheritance showing examples of 
 * base and derived classes
 */

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            // Creating a new object to be passed through multiple classes. 
            Customer thisCustomer = new Customer();
           
            bool exit = false;

            do
            {
                // Displaying the menu to the user.
                Console.Write(StandardMessage.DisplayMenu());

                // Getting the menu choice from the user and passing it through a switch statement.
                switch (Console.ReadLine()) 
                {
                    case "1" :
                        // Taking the blank object and passing it through BuildACustomer class. 
                        // Cleaning Code is used to display information in a readable format.
                        Console.WriteLine(StandardMessage.CleaningCode());
                        BuildCustomer.BuildACustomer(thisCustomer);
                        Console.WriteLine(StandardMessage.CleaningCode());
                        break;

                    case "2" :
                        // Taking the completed object and passing it through a display class 
                        // The display class shows all the information of the newly created customer.
                        Console.WriteLine(StandardMessage.CleaningCode());
                        DisplayCustomerInfo.DisplayCustomer(thisCustomer);
                        Console.WriteLine(StandardMessage.CleaningCode());
                        break;

                    case "3" :
                        // Option to exit out of the program 
                        // In more technical terms this statment in used to exit the loop.
                        Console.WriteLine(StandardMessage.CleaningCode());
                        Console.WriteLine(StandardMessage.DisplayGoodbye());
                        Console.ReadLine();
                        exit = true;
                        break;

                    default :
                        // If user enters an incorrect number for the menu throw an exception.
                        Console.WriteLine(StandardMessage.CleaningCode());
                        Console.WriteLine(StandardMessage.DisplayNumError());
                        break;
                }
            } while (exit == false);
        }
    }
}
