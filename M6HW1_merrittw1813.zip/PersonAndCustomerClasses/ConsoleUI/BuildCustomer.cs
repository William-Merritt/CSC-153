﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PeopleClassLibrary;

namespace ConsoleUI
{
    public static class BuildCustomer
    {
        public static void BuildACustomer(Customer thisCustomer) 
        {
            // String input will be used for the if statment.
            string input;

            // Getting user input and passing entered information into the blank object.
            Console.Write(StandardMessage.GetCustomerName());
            thisCustomer.Name = Console.ReadLine();

            Console.Write(StandardMessage.GetCustomerAddress());
            thisCustomer.Address = Console.ReadLine();

            Console.Write(StandardMessage.GetCustomerTelephoneNum());
            thisCustomer.TelephoneNum = Console.ReadLine();

            Console.Write(StandardMessage.GetCustomerNum());
            thisCustomer.CustomerNum = Console.ReadLine();

            // Boolean cannot be a string. So I needed to create an if statement to implement it correctly.
            Console.Write(StandardMessage.GetMailingListChoice());
            input = Console.ReadLine().ToLower();

            if (input == "yes")
            {
                thisCustomer.MailingList = true;
            }

        }
    }
}
