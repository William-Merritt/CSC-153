﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeopleClassLibrary
{
    public static class StandardMessage
    {
        // This class will hold all of the write line info so that the main does not become messy.
        public static string DisplayMenu() 
        {
            return "1. Create Customer\n2. Display Customer Information\n3. Exit Program" +
                "\nPlease Enter a 1/2/3 ---> ";
        }

        public static string DisplayNumError() 
        {
            return "Error! Incorrect Number Entered.";
        }

        public static string GetCustomerName() 
        {
            return "Enter the name of the customer ---> ";
        }

        public static string GetCustomerAddress() 
        {
            return "Enter the address of the customer ---> ";
        }

        public static string GetCustomerTelephoneNum() 
        {
            return "Enter the telephone number of the customer ---> ";
        }

        public static string GetCustomerNum() 
        {
            return "Enter the customer number ---> ";
        }

        public static string GetMailingListChoice() 
        {
            return "Would the customer like to be added to the mailing list?\n" +
                "Please enter a yes/no ---> ";
        }

        public static string CleaningCode() 
        {
            return " ";
        }

        public static string DisplayGoodbye() 
        {
            return "Have a nice day.";
        }
    }
}
