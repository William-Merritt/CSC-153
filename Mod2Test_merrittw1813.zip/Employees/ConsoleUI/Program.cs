﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
 * William Merritt
 * CSC 153
 * 02/10/2020   
 * Employees Test Review
 */
namespace ConsoleUI
{
    class Program
    {
        
        
        static void Main(string[] args)
        {
            //Create input variable for user input and sentry for loop
            string input;
            bool exit = false;

            //Create a constant variable to hold size of the arrays
            const int SIZE = 5;

            //Creating Index Variables
            int nameIndex =  0;
            int phoneIndex = 0;
            //Do not need an index variable for a list.

            //Create Arrays passing through size array
            string[] employeeNames = new string[SIZE];
            string[] employeePhones = new string[SIZE];

            //Create a List for the employees Age. 
            List<int> employeeAges = new List<int>();

            do
            {
                //Creating the menu for the user to see
                Console.WriteLine("1. Enter Employee's Name"
                    +"\n2. Enter Employee's Phone Number"
                    +"\n3. Enter Employee's Age"
                    +"\n4. Display Employee's Information"
                    +"\n5. Display Average Employee Age"
                    +"\n6. Exit");
                Console.Write("-->");

                input = Console.ReadLine();

                //Creating the Decision Structure (Switch) to dirext proper process

                switch (input) 
                {
                    case "1" :
                        //TODO Entering the Employee's Name
                        Console.Write("Enter Employee's Name --> ");
                        //Overwrite users input from menu Choice.
                        input = Console.ReadLine();
                        //Does not know where to put input at. 
                        //Take each input and passes it through the Array iterating each time.
                        employeeNames[nameIndex] = input;
                        nameIndex++;
                        Console.WriteLine("");
                        break;

                    case "2" :
                        //TODO
                        Console.Write("Enter Employee's Phone Number --> ");
                        input = Console.ReadLine();
                        employeePhones[phoneIndex] = input;
                        phoneIndex++;
                        Console.WriteLine("");
                        break;

                    case "3" :
                        //TODO
                        int number = 0;
                        Console.Write("Enter Employee's Age --> ");
                        input = Console.ReadLine();

                        //Creating an If statment for the try parse.
                        if (int.TryParse(input, out number))
                        {
                            employeeAges.Add(number);
                        }
                        else 
                        {
                            Console.WriteLine("Not a valid number!");
                        }
                        Console.WriteLine("");
                        break;

                    case "4" :
                        //TODO Create a for loop to display the employees information (done)
                        for (int index = 0; index < employeeAges.Count; index++) 
                        {
                            Console.WriteLine($"Employee Name - {employeeNames[index]}");
                            Console.WriteLine($"Employee Phone - {employeePhones[index]}");
                            Console.WriteLine($"Employee Age - {employeeAges[index].ToString()}");
                            Console.WriteLine("");
                        }
                        break;

                    case "5" :
                        //TODO Display the average age (done)
                        //Creating the average of the employee age.
                        Console.WriteLine(employeeAges.Average());
                        Console.WriteLine("");
                        break;

                    case "6" :
                        //TODO Create the quit case (done)
                        Console.WriteLine("Have a nice day.");
                        Console.WriteLine("");
                        exit = true;
                        break;

                    default :
                        Console.WriteLine("Not A Valid Choice!");
                        break;


                }



            } while (exit == false);


        }
    }
}
