﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailClassLibrary
{
    public class StandardMessages
    {
        public static string DisplayHeader() 
        {
            return "Description\tUnits on Hand\tPrice" +
                "\n======================================";
        }

    }
}
