﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RetailClassLibrary;
/**
* 03/29/2020
* CSC 153
* William Merritt
* This program continues on creating classes and manipulating the data into a List. 
*/
namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {

            List<RetailItem> items = new List<RetailItem>();

            Console.WriteLine(StandardMessages.DisplayHeader());

            //Creates a new object and adds it to the items list created above. 
            //Each field should be set in the same subscript. ex. items[0].Description and items[0].UnitsOnHand.
            items.Add(new RetailItem());
            items[0].Description = "Jacket";
            items[0].UnitsOnHand = "12";
            items[0].Price = "59.05";
            
            items.Add(new RetailItem());
            items[1].Description = "Jeans";
            items[1].UnitsOnHand = "40";
            items[1].Price = "34.95";

            items.Add(new RetailItem());
            items[2].Description = "Shirt";
            items[2].UnitsOnHand = "20";
            items[2].Price = "24.95";

            //Specifying the RetailItem datatype. Getting the objects from the list
            //Then save it into another variable that will be passed into a class method.
            foreach (RetailItem getItems in items) 
            {
                Console.WriteLine(getItems.DisplayRetailItems());
            }

            Console.ReadLine();

        }
    }
}
