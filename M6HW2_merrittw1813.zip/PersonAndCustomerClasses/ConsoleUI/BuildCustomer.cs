﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PeopleClassLibrary;

namespace ConsoleUI
{
    public static class BuildCustomer
    {
        public static void BuildACustomer(PreferredCustomer thisCustomer) 
        {
            // String input will be used for the if statment.
            string input;

            // Getting user input and passing entered information into the blank object.
            Console.Write(StandardMessage.GetCustomerName());
            thisCustomer.Name = Console.ReadLine();

            Console.Write(StandardMessage.GetCustomerAddress());
            thisCustomer.Address = Console.ReadLine();

            Console.Write(StandardMessage.GetCustomerTelephoneNum());
            thisCustomer.TelephoneNum = Console.ReadLine();

            Console.Write(StandardMessage.GetCustomerNum());
            thisCustomer.CustomerNum = Console.ReadLine();

            // Boolean cannot be a string. So I needed to create an if statement to implement it correctly.
            Console.Write(StandardMessage.GetMailingListChoice());
            input = Console.ReadLine().ToLower();

            if (input == "yes")
            {
                thisCustomer.MailingList = true;
            }


            Console.Write(StandardMessage.GetAmountPurchased());
            thisCustomer.AmountPurchased = TryParse.ParseToInt(Console.ReadLine());

            // Creating an if else if statement to calculate the Discount Level based on amount purchased input.

            if (thisCustomer.AmountPurchased < 500)
            {
                thisCustomer.DiscountLevel = 0;
            }
            else if (thisCustomer.AmountPurchased < 1000 & thisCustomer.AmountPurchased >= 500)
            {
                thisCustomer.DiscountLevel = 5;
            }
            else if (thisCustomer.AmountPurchased >= 1000 & thisCustomer.AmountPurchased < 1500)
            {
                thisCustomer.DiscountLevel = 6;
            }
            else if (thisCustomer.AmountPurchased >= 1500 & thisCustomer.AmountPurchased < 2000)
            {
                thisCustomer.DiscountLevel = 7;
            }
            else if (thisCustomer.AmountPurchased >= 2000)
            {
                thisCustomer.DiscountLevel = 10;
            }
            else 
            {
                Console.WriteLine(StandardMessage.DisplayNumError());
            }

        }
    }
}
