﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeopleClassLibrary
{
    public class Customer : Person
    {
        // Fields
        private string _customerNum;
        private bool _mailingList;

        // Constructors
        public Customer() 
        {
            CustomerNum = "";
            MailingList = false;
        }

        public Customer(string name, string address, string telephoneNum, string customerNum, bool mailingList) 
        {
            Name = name;
            Address = address;
            TelephoneNum = telephoneNum;
            CustomerNum = customerNum;
            MailingList = mailingList;
        }

        // Properties
        public string CustomerNum 
        {
            get 
            {
                return _customerNum;
            }
            set 
            {
                _customerNum = value;
            }
        }

        public bool MailingList 
        {
            get 
            {
                return _mailingList;
            }
            set 
            {
                _mailingList = value;
            }
        }
        
    }
}
