﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeopleClassLibrary
{
    public class PreferredCustomer : Customer
    {
        // Fields
        private int _amountPurchased;
        private int _discountLevel;

        // Constructor
        public PreferredCustomer() 
        {
            AmountPurchased = 0;
            DiscountLevel = 0;
        }

        public PreferredCustomer(string name, string address, string telephoneNum, string customerNum, 
                                    bool mailingList, int amountPurchased, int discountLevel ) 
        {
            Name = name;
            Address = address;
            TelephoneNum = telephoneNum;
            CustomerNum = customerNum;
            MailingList = mailingList;
            AmountPurchased = amountPurchased;
            DiscountLevel = discountLevel;
        }

        // Properties
        public int AmountPurchased 
        {
            get 
            {
                return _amountPurchased;
            }
            set 
            {
                _amountPurchased = value;
            }
        }

        public int DiscountLevel 
        {
            get 
            {
                return _discountLevel;
            }
            set 
            {
                _discountLevel = value;
            }
        }

        // Methods
    }
}
