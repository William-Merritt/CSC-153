﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameWorld
{
    // Base Class for all weapons to be created. 
    public class Weapon
    {
        //Fields
        private string _weaponName;
        private string _weaponType;
        private int _damageAmount;
        //Constructors
        public Weapon() 
        {
            WeaponName = "";
            WeaponType = "";
            DamageAmount = 0;
        }

        public Weapon(string weaponName, string weaponType, int damageAmount) 
        {
            WeaponName = weaponName;
            WeaponType = weaponType;
            DamageAmount = damageAmount;
        }
        //Properties
        public string WeaponName 
        { 
            get 
            {
                return _weaponName;
            }
            set 
            {
                _weaponName = value;
            } 
        }
        public string WeaponType 
        { 
            get 
            {
                return _weaponType;
            } 
            set 
            {
                _weaponType = value;
            } 
        }
        public int DamageAmount
        {
            get
            {
                return _damageAmount;
            }
            set
            {
                _damageAmount = value;
            }
        }
        //Methods
    }
}
