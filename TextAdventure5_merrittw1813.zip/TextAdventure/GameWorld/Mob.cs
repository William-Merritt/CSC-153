﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameWorld
{
    public class Mob : LivingCreature
    {
        //  Fields
        //private string _firstName;
        //private string _lastName;
        private string _mobType;
        private string _mobWeakness;
       

        // Constructors
        public Mob() 
        {
            FirstName = "";
            LastName = "";
            MobType = "";
            MobWeakness = "";
            Health = 0;
            Race = "";
        }

        public Mob(string firstName, string lastName, string mobType, string mobWeakness, int health, string race) :
                    base(firstName, lastName, health, race)
        {
            MobType = mobType;
            MobWeakness = mobWeakness; 
        }

        // Properties

        public string MobType 
        {
            get 
            {
                return _mobType;
            }
            set 
            {
                _mobType = value;
            }
        }

        public string MobWeakness 
        {
            get 
            {
                return _mobWeakness;
            }
            set 
            {
                _mobWeakness = value;
            }
        }


    }
}
