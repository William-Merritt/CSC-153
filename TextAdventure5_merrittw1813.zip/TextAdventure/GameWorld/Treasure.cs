﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameWorld
{
    public class Treasure : Item
    {
        // Fields
        private string _itemRarity;
        // Constructor
        public Treasure() 
        {
            ItemName = "";
            ItemDesc = "";
            ItemCost = 0;
            ItemRarity = "";
        }

        public Treasure(string itemName, string itemDesc, int itemCost, string itemRarity) 
                            : base(itemName, itemDesc, itemCost) 
        {
            ItemRarity = itemRarity;
        }
        
        // Properties
        public string ItemRarity 
        {
            get 
            {
                return _itemRarity;
            }
            set 
            {
                _itemRarity = value;
            }
        }
        
        // Methods
    }
}
