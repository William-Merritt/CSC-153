﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameWorld
{
    // Base class for all items. 
    public class Item
    {
        // Fields
        // Constructor
        public Item() 
        {
            ItemName = "";
            ItemDesc = "";
            ItemCost = 0;
        }

        public Item(string itemName, string itemDesc, int itemCost) 
        {
            ItemDesc = itemDesc;
            ItemName = itemDesc;
            ItemCost = itemCost;

        }

        // Properties
        public string ItemDesc { get; set; }
        public string ItemName { get; set; }
        public int ItemCost { get; set; }

        // Methods
    }
}
