﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameWorld
{
    public class Potion : Item
    {
        // Fields
        private int _replinishAmt;
        // Constructor
        public Potion() 
        {
            ItemName = "";
            ItemDesc = "";
            ItemCost = 0;
            ReplinishAmt = 0;
        }

        public Potion(string itemName, string itemDesc, int itemCost, int replinishAmt) 
                        : base (itemName, itemDesc, itemCost)
        {
            ReplinishAmt = replinishAmt;
        }
        // Properties
        public int ReplinishAmt 
        {
            get 
            {
                return _replinishAmt;
            }
            set 
            {
                _replinishAmt = value;
            }
        }
        // Methods
    }
}
