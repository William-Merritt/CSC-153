﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GameWorld;

/**
* 05/10/2020
* CSC 153
* William Merritt
* This program will be the fifth pass of the Text Adventure.
* Semester Project.
*/


namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            int index = 0;

            //Creating the player.
            Player thisPlayer = new Player();

            //Creating Room Objects for the player to move through.
            Room[] rooms = {  new Room("Entrance", "Castle walls with iron gates", "Exit North"),
                              new Room("Plaza", "Destroyed slums with many homeless citizens", "Move North or South"),
                              new Room("Alley", "Slightly lit back alley with multiple cages of dogs", "Move North or South"),
                              new Room("Field", "Grass plain with multiple groups of soilders","Move  North or South"),
                              new Room("Castle", "Highly guarded fortress that is overun by the militia", "Move South")};
            
            //Creating Mob Objects to be used later. 
            List<Mob> mobs = new List<Mob>() { new Mob("Death", "Knight", "Bleed", "Fire", 200, "Undead"),
                                               new Mob("Soilder","Grunt", "Shock", "Pierce", 150, "Dracokin"),
                                               new Mob("Commander","Silva","Burn", "Slash", 300, "Giant"),
                                               new Mob("Calvary","BlackWind", "Trample", "Bleed", 250, "Elf"),
                                               new Mob("Rabid","Dog", "Bite", "Fire", 100, "Beast")};

            
            //Creating Weapon objects to be used by the player to fight the mobs.
            Weapon[] weapons = { new Weapon("Sword", "Slash", 25), 
                                 new Weapon("Lance", "Pierce", 28), 
                                 new Weapon("Axe", "Cut", 30), 
                                 new Weapon("Bow", "Pierce", 15)};
            
            //Creating potions to be used by the player to recover stamina or heal. 
            Potion[] potions ={ new Potion("Health Potion", "Replinishes health on use", 100, 25 ), 
                                new Potion("Stamina Potion", "Replinishes stamina on use", 20, 40)};
            
            //Creating an array to hold the different treasures that can be found in the game. 
            Treasure[] treasure = { new Treasure("Gold Bag", "Bag that holds 30 gold pieces", 30, "common"), 
                                    new Treasure("Map","Points you towards the path of the castle", 10, "rare"), 
                                    new Treasure("Gemstone", "Can be sold at a marketplace", 100, "uncommon")};
            
            // Creating a list to hold the item class objects.
            List<Item> items = new List<Item>() { new Item("Food", "Meat that can be cooked and eaten to regain health", 15), 
                                                  new Item("Armor", "Armor plating that can be equppied to increase defensive stat", 55), 
                                                  new Item("Metals", "Iron that can be used in crafting", 20), 
                                                  new Item("Ring", "Wedding ring that belongs to someone", 5)};

            do
            {
                
                Console.WriteLine(StandardMessages.DisplayMenu());
                

                //Taking the user's choice and passing it through a switch statement. Using console.readline for the argument. 
                switch (Console.ReadLine()) 
                {
                    case "1":
                        BuildPlayer.BuildAPlayer(thisPlayer);
                        StandardMessages.CleaningCode();
                        StandardMessages.DisplayCreatedPlayer(thisPlayer);
                        break;

                    case "2":
                        //Issues showing rooms. Class looks correct and Array looks correct. 
                        StandardMessages.CleaningCode();
                        Console.WriteLine(StandardMessages.DisplayCurrentRoom(rooms, ref index));
                        GameAction.MoveNorth(rooms, ref index);
                        StandardMessages.CleaningCode();
                        break;

                    case "3" :
                        //Issues showing rooms. Class looks correct and Array looks correct. 
                        StandardMessages.CleaningCode();
                        Console.WriteLine(StandardMessages.DisplayCurrentRoom(rooms, ref index));
                        GameAction.MoveSouth(rooms, ref index);
                        StandardMessages.CleaningCode();
                        break;

                    case "4":
                        //TODO figure out how to manipulate objects more. Selecting a random mob to appear.
                        GameAction.Attack(mobs[0]);
                        StandardMessages.CleaningCode();
                        break;

                    case "5":
                        //Exit the program --> Set the boolean variable to true and display goodbye message. 
                        Console.WriteLine(StandardMessages.DisplayGoodbye());
                        Console.ReadLine();
                        exit = true; 
                        break;

                    default :
                        //Call number error message for incorrect menu choice. 
                        Console.WriteLine(StandardMessages.DisplayNumberError());
                        Console.ReadLine();
                        break;
                }


            } while (exit == false);
        }
    }
}
