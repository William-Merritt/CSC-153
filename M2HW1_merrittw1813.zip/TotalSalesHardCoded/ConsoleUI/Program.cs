﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
* 01/29/2020
* CSC 153
* William Merritt
* This program will take values in an array and output it back out to the user.
*/


namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            //Creating the array and adding the numbers in. 
            double[] numbers = new double[7] {1245.67, 1189.55, 1098.72, 1456.88
            , 2109.34, 1987.55, 1872.36};

            //Using Array.Sort to sort out the list in ascending order. 
            Array.Sort(numbers);

            //Foreach loops through the elements in the array and will display them inside the console.
            foreach (double element in numbers)
            {
                Console.WriteLine(element);
            }
            Console.ReadLine();
        }
    }
      
}
