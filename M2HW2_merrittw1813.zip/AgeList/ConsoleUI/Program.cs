﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            int numAges = 0;
            string input;
            int items = 0;
            List<int> ages = new List<int>();
            bool exit = true;

            //Creating a do-while to loop through the program at least once and then continue on until the user quits. 
            do
            {
                //Creating the menu for the user 
                Console.WriteLine("Please select a menu option"
                    + "\n1. Enter Number of Ages"
                    + "\n2. Enter Ages Desired"
                    + "\n3. Display Ages in List"
                    + "\n4. Display Average of Ages"
                    + "\n5. Exit The Program");

                //Creating a variable to hold the users menu choice
                string menuOption = System.Console.ReadLine();

                //Running the menu choice through a switch statement with multiple cases. 
                switch (menuOption) 
                {
                    case "1" :
                        Console.WriteLine("Please enter how many ages you would like to input > ");
                        //Coverting the input from strings to int. Could have used parse but not sure how to use it exactly. 
                        input = Console.ReadLine();
                        numAges = System.Convert.ToInt32(input);
                        break;
                    
                    case "2" :
                        //Adding the ages into the list for the user. Taking each age and appending it to the list. 
                        while (items <= numAges)
                        {
                            Console.WriteLine("Please enter an age > ");
                            string getAge = Console.ReadLine();
                            int element = System.Convert.ToInt32(getAge);
                            ages.Add(element);
                            items++;
                        }
                        break;
                        //Using break to prevent fallthrough within the switch statement. 

                    case "3" :
                        Console.WriteLine("We will now display the list of Ages");
                        foreach (var element in ages) 
                        {
                            Console.WriteLine(element);
                        }
                        Console.ReadLine();
                        break;
                    
                    case "4" :
                        Console.WriteLine("We will now display the average of the ages inputted");
                        double average = ages.Average();
                        Console.WriteLine($"The average age is {average}. ");
                        Console.WriteLine(" ");
                        break;

                    case "5":
                        //Creating a quit option for the user. Comparing exit to the boolean variable above and throught the do-while. 
                        Console.WriteLine("Have a nice day");
                        Console.ReadLine();
                        exit = false;
                        break;


                    default :
                        //Creating a default statement that tells the user to enter a correct value.
                        System.Console.WriteLine("\nERROR:  Enter a value from 1-9. "
                            + "Push Enter to quit");
                        break;
                }

                
            } while(exit != false);
        }
    }
}
