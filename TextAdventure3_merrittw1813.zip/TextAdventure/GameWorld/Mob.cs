﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameWorld
{
    public class Mob
    {
        //  Fields

        private string _mobName;
        private string _mobType;
        private string _mobWeakness;
        private int _mobHealth;

        // Constructors
        public Mob() 
        {
            MobName = "";
            MobType = "";
            MobWeakness = "";
            MobHealth = 0;
        }

        public Mob(string mobName, string mobType, string mobWeakness, int mobHealth) 
        {
            MobName = mobName;
            MobType = mobType;
            MobWeakness = mobWeakness;
            MobHealth = mobHealth;
        }

        // Properties
        public string MobName 
        {
            get 
            {
                return _mobName;
            }
            set 
            {
                _mobName = value;
            }
        }

        public string MobType 
        {
            get 
            {
                return _mobType;
            }
            set 
            {
                _mobType = value;
            }
        }

        public string MobWeakness 
        {
            get 
            {
                return _mobWeakness;
            }
            set 
            {
                _mobWeakness = value;
            }
        }

        public int MobHealth 
        {
            get 
            {
                return _mobHealth;
            }
            set 
            {
                _mobHealth = value;
            }
        }

    }
}
