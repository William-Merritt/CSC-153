﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameWorld
{
    public class Player
    {
        // Fields

        private string _name;
        private string _password;
        private string _playerClass;
        private string _race;

        public bool IsAuthenticated;

        // Constructor
        public Player() 
        {
            Name = "";
            PlayerClass = "";
            Race = "";
            Password= "";
        }
        public Player(string name, string playerClass, string race, string password) 
        {
            Name = name;
            PlayerClass = playerClass;
            Race = race;
            Password = _password;
            
        }

        //Properties
        public string Name 
        {
            get 
            {
                return _name;
            }
            set 
            {
                _name = value;
            }
        }

        public string Password 
        {
            get 
            {
                return _password;
            }
            set 
            {
                _password = value;
            }
        }

        public string PlayerClass 
        {
            get 
            {
                return _playerClass;
            }
            set 
            {
                _playerClass = value;
            }
        }

        public string Race 
        {
            get 
            {
                return _race;
            }
            set 
            {
                _race = value;
            }
        }

        //Creating Password Check
        public bool Logon(string password) 
        {
            if (Password == password) 
            {
                IsAuthenticated = true;
            }
            return IsAuthenticated;
        }

        public bool GetIsAuthenticated() 
        {
            return IsAuthenticated;
        }
    }
}
