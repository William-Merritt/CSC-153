﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace GameWorld
{
    public class Room
    {
        // Fields
        private string _roomName;
        private string _roomDesc;
        private string _exits;

        //Construtors
        public Room()
        {
            RoomName = "";
            RoomDesc = "";
            Exits = "";

        }

        public Room(string roomName, string roomDesc, string exits)
        {
            RoomName = roomName;
            RoomDesc = roomDesc;
            Exits = exits;
        }


        //Properties
        public string RoomName
        {
            get
            {
                return _roomName;
            }
            set
            {
                _roomName = value;
            }
        }

        public string RoomDesc
        {
            get
            {
                return _roomDesc;
            }
            set
            {
                _roomDesc = value;
            }
        }

        public string Exits
        {
            get
            {
                return _exits;
            }
            set
            {
                _exits = value;
            }
        }

    }
}
