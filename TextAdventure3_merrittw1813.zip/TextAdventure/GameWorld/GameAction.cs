﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GameWorld;

namespace GameWorld
{
    public static class GameAction
    {
        /**
         * Creating the Second iteration of the Text Adventure Project
         */
        
        public static void MoveNorth(Room[] rooms, ref int index) 
        {
            if (index < rooms.Length)//Creating an if statement to consider out of bounds error. 
            {
                if (index != rooms.Length - 1)
                {
                    index++;
                    Console.WriteLine(rooms[index]);
                }
                else
                {
                    Console.WriteLine("No More Rooms!");
                }

            }

        }

        public static void MoveSouth(Room[] rooms, ref int index) 
        {
            //Move through the array in reverse and display a previous room each time called.
            if (index > 0)
            {
                index--;
                Console.WriteLine(rooms[index]);
            }
            else 
            {
                Console.WriteLine("No More Rooms!");
            }

        }

        public static int Attack(Mob inputMob) 
        {
            
            Console.WriteLine($"Fighting --->{inputMob.MobName}\n" +
                              $"Boss Current HP is --> {inputMob.MobHealth}");
            
            Console.WriteLine(" ");
            
            Random rand = new Random();

            int combat = rand.Next(20) + 1;

            Console.WriteLine($"You hit the boss for {combat} points! ");
            Console.WriteLine(" ");

            inputMob.MobHealth -= combat;
            
            Console.WriteLine($"Boss Current HP is --> {inputMob.MobHealth}");
            Console.WriteLine(" ");

            return inputMob.MobHealth;

        }

    }
}
