﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GameWorld;

/**
* 04/05/2020
* CSC 153
* William Merritt
* This program will be the fourth pass of the Text Adventure 
* Semester Project.
*/


namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            int index = 0;

            //Creating the player.
            Player thisPlayer = new Player();

            //Creating Room Objects for the player to move through.
            Room[] rooms = {  new Room("Entrance", "Castle walls with iron gates", "Exit North"),
                              new Room("Plaza", "Destroyed slums with many homeless citizens", "Move North or South"),
                              new Room("Alley", "Slightly lit back alley with multiple cages of dogs", "Move North or South"),
                              new Room("Field", "Grass plain with multiple groups of soilders","Move  North or South"),
                              new Room("Castle", "Highly guarded fortress that is overun by the militia", "Move South")};
            
            //Creating Mob Objects to be used later. 
            List<Mob> mobs = new List<Mob>() { new Mob("Knight", "Bleed", "Fire", 200),
                                               new Mob("Soilder", "Shock", "Pierce", 150),
                                               new Mob("Commander","Burn", "Slash", 300),
                                               new Mob("Calvary", "Trample", "Bleed", 250),
                                               new Mob("Dog", "Bite", "Fire", 100)};

            //Creating the weapons, potions, treasure, and items array/lists to be used later.
            string[] weapons = new string[4] { "Sword", "Lance", "Axe", "Bow" };
            string[] potions = new string[2] { "Health Potion", "Stamina Potion" };
            string[] treasure = new string[3] { "Money", "Scroll", "Gemstone" };
            List<string> items = new List<string>() { "Food", "Armor", "Metals", "Ring" };

            do
            {
                

                Console.WriteLine(StandardMessages.DisplayMenu());
                

                //Taking the user's choice and passing it through a switch statement. Using console.readline for the argument. 
                switch (Console.ReadLine()) 
                {
                    case "1":
                        BuildPlayer.BuildAPlayer(thisPlayer);
                        StandardMessages.CleaningCode();
                        StandardMessages.DisplayCreatedPlayer(thisPlayer);
                        break;

                    case "2":
                        //Issues showing rooms. Class looks correct and Array looks correct. 
                        GameAction.MoveNorth(rooms, ref index);
                        break;

                    case "3" :
                        //Issues showing rooms. Class looks correct and Array looks correct. 
                        GameAction.MoveSouth(rooms, ref index);
                        break;

                    case "4":
                        //TODO figure out how to manipulate objects more. Selecting a random mob to appear.
                        GameAction.Attack(mobs[0]);
                        break;

                    case "5":
                        //Exit the program --> Set the boolean variable to true and display goodbye message. 
                        Console.WriteLine(StandardMessages.DisplayGoodbye());
                        Console.ReadLine();
                        exit = true; 
                        break;

                    default :
                        //Call number error message for incorrect menu choice. 
                        Console.WriteLine(StandardMessages.DisplayNumberError());
                        Console.ReadLine();
                        break;
                }


            } while (exit == false);
        }
    }
}
