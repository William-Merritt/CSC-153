﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
* 02/20/2020
* CSC 153
* William Merritt
* Finding the distance of an object falling by gravity. Includes classes, methods, and void methods. 
*/


namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false; //This will be used as a sentry for the do-while loop.
            string input; //To hold the menu choice
            string inputString;//To hold result from TryParse
            int time = 0; //Intializing time to hold result from method

            do
            {
                StandardMessage.DisplayMenu();
                input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        StandardMessage.AskForTime();
                        inputString = Console.ReadLine();
                        time = Calculator.Calculating.ConvertingString(ref inputString);
                        StandardMessage.CleaningCode();
                        break;

                    case "2":
                        StandardMessage.CleaningCode();
                        double distance = Calculator.Calculating.FallingDistance(time);
                        StandardMessage.DisplayDistance(ref distance);
                        StandardMessage.CleaningCode();
                        break;

                    case "3":
                        StandardMessage.DisplayGoodbye();
                        Console.ReadLine();
                        exit = true;
                        break;

                    default:
                        StandardMessage.DisplayMenuError();
                        StandardMessage.CleaningCode();
                        break;
                }

            } while (exit == false);


        }


    }
}
