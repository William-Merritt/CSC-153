﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    public static class StandardMessage
    {
        public static void DisplayMenu() 
        {
            Console.WriteLine("1. Enter Amount Of Time Object Has Fallen.");
            Console.WriteLine("2. Display Distance Object Has Fallen.");
            Console.WriteLine("3. Exit The Program.");
            Console.Write("Please enter a 1/2/3 ---> ");
            
        }

        public static void DisplayGoodbye() 
        {
            Console.WriteLine("Have a nice day");
        }

        public static void DisplayMenuError() 
        {
            Console.WriteLine("Error! Enter a 1, 2, or 3.");
        }

        public static void AskForTime()
        {
            Console.Write("Enter the amount of time the item has been falling in seconds ---> ");
        }

        public static void DisplayDistance(ref double distance)
        { 
            Console.WriteLine("The distance fallen in meters is ----> {0}", distance);
        }

        public static void CleaningCode() 
        {
            Console.WriteLine(" ");
        }
    }
}
