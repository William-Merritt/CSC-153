﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    public static class Calculating
    {
        public static int ConvertingString(ref string inputString) 
        {
            if (int.TryParse(inputString, out int time)) 
            {
                Console.WriteLine("Time entered has been added to the formula");
            }
            return time;
        }

        public static double FallingDistance(int time) 
        {
            double distance = 0.5 * 9.8 * (time * time);

            return distance;
        }

    }
}
