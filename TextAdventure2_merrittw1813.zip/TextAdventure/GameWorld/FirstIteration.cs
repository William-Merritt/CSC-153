﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameWorld
{
    public static class FirstIteration
    {
        /**
         * This is the first iteration of this project
         * It refernces the old menu and the loops used to 
         * run through each array or list that has been created ealier.
         * Left in gameworld for refernce if needed later on.
         */

        public static void DisplayRooms(ref string[] rooms) 
        {
            Console.WriteLine("These are the rooms of Larvan"
                           + "\n==============================");
            foreach (string element in rooms)
            {
                Console.WriteLine(element);
            }
            Console.WriteLine("Please press ENTER once to continue");
        }

        public static void DisplayWeapons(ref string[] weapons)
        {
            Console.WriteLine("These are the Weapons"
                            + "\n============================");

            System.Array.Sort(weapons);

            foreach (string element in weapons)
            {
                Console.WriteLine(element);
            }
            Console.WriteLine("Please press ENTER once to continue");
            Console.ReadLine();
        }

        public static void DisplayPotions(ref string[] potions)
        {
            Console.WriteLine("These are your current Potions"
                           + "\n===========================");
            foreach (string element in potions)
            {
                Console.WriteLine(element);
            }
            Console.WriteLine("Please press ENTER once to continue");
            Console.ReadLine();
        }

        public static void DisplayTreasures(ref string[] treasure)
        {
            Console.WriteLine("These are your current Treasures"
                          + "\n===========================");
            foreach (string element in treasure)
            {
                Console.WriteLine(element);
            }
            Console.WriteLine("Please press ENTER once to continue");
            Console.ReadLine();
        }

        public static void DisplayItems(ref List<string> items)
        {
            Console.WriteLine("These are your current Items"
                          + "\n===========================");
            foreach (string element in items)
            {
                Console.WriteLine(element);
            }
            Console.WriteLine("Please press ENTER once to continue");
            Console.ReadLine();
        }

        public static void DisplayMobs(ref List<string> mobs) 
        {
            Console.WriteLine("These are the current Mobs of Larvan"
                         + "\n===========================");
            foreach (string element in mobs)
            {
                Console.WriteLine(element);
            }
            Console.WriteLine("Please press ENTER once to continue");
            Console.ReadLine();
        }






    }
}
