﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameWorld
{
    public static class SecondIteration
    {
        /**
         * Creating the Second iteration of the Text Adventure Project
         */
        
        public static void MoveNorth(string[] rooms) 
        {

            for (int index = 0; index < rooms.Length; index++)
            {
                Console.WriteLine(rooms[index]);
                index += rooms.Length;
            }
            //Was able to figure out how to display one room, but could not figure out how to iterate to next room.
            
        }

        public static void MoveSouth(string[] rooms) 
        {
            //Move through the array in reverse and display a previous room each time called.
            for (int index = 0; index < rooms.Length + 1; index--)
            {
                Console.WriteLine(rooms[index]);
            }

        }

        public static int Attack(ref int hitPoints) 
        {

            Console.WriteLine($"Boss Current HP is --> {hitPoints}");
            Console.WriteLine(" ");
            
            Random rand = new Random();

            int combat = rand.Next(20) + 1;

            Console.WriteLine($"You hit the boss for {combat} points! ");
            Console.WriteLine(" ");

            hitPoints -= combat;
            
            Console.WriteLine($"Boss Current HP is --> {hitPoints}");
            Console.WriteLine(" ");

            return hitPoints;

        }

    }
}
