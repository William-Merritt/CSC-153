﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    public static class StandardMessages
    {
        public static void DisplayMenu() 
        {
            Console.WriteLine("1. Move North");
            Console.WriteLine("2. Move South");
            Console.WriteLine("3. Attack");
            Console.WriteLine("4. Exit Program");
            Console.Write("Enter a 1/2/3/4 ---> ");
        }

        public static void DisplayNumberError() 
        {
            Console.WriteLine("Error! Enter a 1/2/3/4");
        }

        public static void DisplayGoodbye() 
        {
            Console.WriteLine("Thanks for playing!");
        }

        public static void CleaningCode() 
        {
            Console.WriteLine(" ");
        }
    }
}
