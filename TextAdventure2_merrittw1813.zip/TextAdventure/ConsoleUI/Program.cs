﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
* 03/1/2020
* CSC 153
* William Merritt
* This program will be the first pass of the Text Adventure 
* Semester Project.
*/


namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            string input;  //To hold the user's menu choice
            
            
            string[] rooms;
            string[] weapons;
            string[] potions;
            string[] treasure;
            
            List<string> items;
            List<string> mobs;

            
            int hitPoints = 100;

            rooms = new string[5] { "Entrance", "Plaza", "Alley", "Field", "Castle" };
            weapons = new string[4] { "Sword", "Lance", "Axe", "Bow" };
            potions = new string[2] { "Health Potion", "Stamina Potion" };
            treasure = new string[3] { "Money", "Scroll", "Gemstone" };

            items = new List<string>() { "Food", "Armor", "Metals", "Ring" };
            mobs = new List<string>() { "Knight", "Soilder", "Commander", "Calvary",
                "Dogs"};
            
            do
            {
                

                StandardMessages.DisplayMenu();
                input = Console.ReadLine();

                //Taking the user's choice and passing it through a switch statement. 
                switch (input) 
                {
                    case "1":
                        //Move North --> Display new room to user in a numeric value starting at 1.
                        GameWorld.SecondIteration.MoveNorth(rooms);
                        //Could not figure out iteration
                        break;

                    case "2":
                        //Move South --> Display previous room however location cannot go below 0.
                        GameWorld.SecondIteration.MoveSouth(rooms);
                        //Could not figure out iterations. 
                        break;

                    case "3":
                        /**
                         * Attack --> Combat. Where a random number between 1 and 20 is chosen 
                         * to be taken away from a simulated hit count.
                         */
                        GameWorld.SecondIteration.Attack(ref hitPoints);
                        //Hit points work.
                        break;

                    case "4":
                        //Exit the progra --> Set the boolean variable to true and display goodbye message. 
                        StandardMessages.DisplayGoodbye();
                        Console.ReadLine();
                        exit = true; 
                        break;

                    default :
                        //Call number error message for incorrect menu choice. 
                        StandardMessages.DisplayNumberError();
                        Console.ReadLine();
                        break;
                }


            } while (exit == false);
        }
    }
}
