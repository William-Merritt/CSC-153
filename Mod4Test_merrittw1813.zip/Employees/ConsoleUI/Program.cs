﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLibrary;
/**
 * William Merritt
 * CSC 153
 * 04/01/2020   
 * Employees Test Creating an employee class and manipulating data. 
 */
namespace ConsoleUI
{
    class Program
    {
        
        
        static void Main(string[] args)
        {
            //Create input variable for user input and sentry for loop
            string input;
            bool exit = false;


            //Create a List for the employees
            List<EmployeeLibrary.Employee> employees = new List<EmployeeLibrary.Employee>();

            do
            {
                //Calling the menu void method to display to the user and get back input
                Console.WriteLine(StandardMessages.DisplayMenu());
                input = Console.ReadLine();

                //Creating the Decision Structure (Switch) to direct proper process
                switch (input) 
                {
                    case "1" :
                        StandardMessages.CleaningCode();
                        BuildEmployee.BuildAEmployee(employees);
                        StandardMessages.CleaningCode();
                        break;

                    case "2" :
                        StandardMessages.CleaningCode();
                        StandardMessages.DisplayEmployee(employees);
                        StandardMessages.CleaningCode();
                        break;

                    case "3" :
                        StandardMessages.CleaningCode();
                        StandardMessages.DisplayAverageAge(employees);
                        StandardMessages.CleaningCode();
                        break;

                    case "4" :
                        StandardMessages.CleaningCode();
                        StandardMessages.DisplayGoodbye();
                        StandardMessages.CleaningCode();
                        exit = true;
                        break;

                    default :
                        Console.WriteLine(StandardMessages.DisplayNumberError());
                        break;


                }

            } while (exit == false);


        }
    }
}
