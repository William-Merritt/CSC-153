﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class Employee
    {
        // Fields

        private string _name;
        private string _phoneNum;
        private int _empAge;

        // Constructors
        public Employee() 
        {
            Name = "";
            PhoneNum = "";
            EmpAge = 0;
        }

        public Employee(string name, string phoneNum, int empAge) 
        {
            Name = name;
            PhoneNum = phoneNum;
            EmpAge = empAge;
        }

        // Properties
        public string Name 
        {
            get 
            {
                return _name;
            }
            set 
            {
                _name = value;
            }
        }

        public string PhoneNum 
        {
            get 
            {
                return _phoneNum;
            }
            set 
            {
                _phoneNum = value;
            }
        }

        public int EmpAge 
        {
            get 
            {
                return _empAge;
            }
            set 
            {
                _empAge = value;
            }
        }

        // Methods
       
    }
}
