﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLibrary;

namespace EmployeeLibrary
{
    public class BuildEmployee
    {
        public static void BuildAEmployee(List<Employee> inputEmployee) 
        {
            Employee thisEmployee = new Employee();
            bool error = true;

            do
            {
                Console.Write("Enter the name of the employee --->");
                thisEmployee.Name = Console.ReadLine();

                Console.Write("Enter the employee phone number --->");
                thisEmployee.PhoneNum = Console.ReadLine();

                Console.Write("Enter the age of the employee --->");
                thisEmployee.EmpAge = ConvertToInt(Console.ReadLine());

                if (thisEmployee.EmpAge < 0)
                {
                    error = true;
                    Console.WriteLine("Error! Incorrect input entered for age");
                }
                else 
                {
                    error = false;
                }


            } while (error == true);

            inputEmployee.Add(thisEmployee);
        }

        public static int ConvertToInt(string input) 
        {
            int output = 0;

            if (int.TryParse(input, out output))
            {
                return output;
            }
            else
            {
                output = -1;
                return output;
            }
        }
    }
}
