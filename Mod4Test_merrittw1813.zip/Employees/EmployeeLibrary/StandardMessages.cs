﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLibrary;

namespace EmployeeLibrary
{
    public static class StandardMessages
    {
        public static string DisplayMenu() 
        {
            return "1. Enter Employee Information\n" +
                "2. Display Employee Information\n" +
                "3. Display Average Age of Employees\n" +
                "4. Exit";
        }

        public static string DisplayGoodbye() 
        {
            return "Have a nice day";
        }

        public static void CleaningCode() 
        {
            Console.WriteLine(" ");
        }

        public static string DisplayNumberError()
        {
            return "Error! Not a valid number!";
        }

        public static void DisplayEmployee(List<Employee> employees) 
        {
            foreach (var employee in employees) 
            {
                Console.WriteLine($"Employee Name --> {employee.Name}" +
                    $"\nEmployee Phone Number --> {employee.PhoneNum}" +
                    $"\nEmployee Age --> {employee.EmpAge}");
            }
        }

        public static void DisplayAverageAge(List<Employee> employees) 
        {
            double output = 0;
            foreach (var employee in employees)
            {
                output += employee.EmpAge;

            }
            double average = output / employees.Count;
            
            CleaningCode();
            Console.WriteLine($"The average employee age is ---> {average}  ");
        }

    }
}
